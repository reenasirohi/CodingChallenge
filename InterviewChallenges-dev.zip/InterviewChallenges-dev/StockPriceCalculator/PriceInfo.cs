﻿namespace InterviewChallenges
{
    /// <summary>
    /// Class to provide information on stock price information.
    /// </summary>
    public class PriceInfo
    {
        /// <summary>
        /// The day which the <see cref="Price"/> relates.
        /// </summary>
        public int Day { get; }

        /// <summary>
        /// The price of the stock on the given <see cref="Day"/>
        /// </summary>
        public double Price { get; }

        /// <summary>
        /// Creates a new instance of <see cref="PriceInfo"/>,
        /// </summary>
        /// <param name="day">The day which the price relates.</param>
        /// <param name="price">The price of the stock on the given day.</param>
        public PriceInfo(int day, double price)
        {
            this.Day = day;
            this.Price = price;
        }
    }
}
