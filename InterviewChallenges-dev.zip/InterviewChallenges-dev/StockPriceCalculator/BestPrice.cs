﻿namespace InterviewChallenges
{
    /// <summary>
    /// Class for defining the best buy and sell information.
    /// </summary>
    public class BestPrice
    {
        /// <summary>
        /// Defines the buy information.
        /// </summary>
        public PriceInfo BuyInfo { get; set; }

        /// <summary>
        /// Defines the sell information.
        /// </summary>
        public PriceInfo SellInfo { get; set; }

        /// <summary>
        /// Creates a new instance of <see cref="BestPrice"/>
        /// </summary>
        /// <param name="buyInfo">The best day and price to buy.</param>
        /// <param name="sellInfo">The best day and price to sell.</param>
        public BestPrice(PriceInfo buyInfo, PriceInfo sellInfo)
        {
            this.BuyInfo = buyInfo;
            this.SellInfo = sellInfo;
        }
    }
}
