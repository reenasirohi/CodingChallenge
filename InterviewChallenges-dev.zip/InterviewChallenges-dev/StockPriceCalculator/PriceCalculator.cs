﻿namespace InterviewChallenges
{
    public class PriceCalculator
    {
        /*
        Given an array of doubles representing stock prices on each day of the month, create a *GetBuyAndSellDays()* function that returns the best day and price to buy and sell shares to 
        make the maximum profit. Remember, you can't sell before you have bought, and you can't buy on the last day of the month.

        For example:

                Given the dataset prices = [18.93,20.25,17.05,16.59,21.09,16.22,21.43,27.13,18.62,21.31,23.96,25.52,19.64,23.49,15.28,22.77,
                                            23.1,26.58,27.03,23.75,27.39,15.93,17.83,18.82,21.56,25.33,25,19.33,22.08,24.03]
                the best day to buy is day 5 [15,15.28] and the best day to sell is day 21 [21,27.39], so:

                GetBuyAndSellDay(prices) will return a BestPrice object containing:

                    BestPrice.BuyDay = 15
                    BestPrice.BuyPrice = 15.28
                    BestPrice.SeellDay = 21
                    BestPrice.SellPrice = 27.39
         */
        public BestPrice GetBuyAndSellDay(double[] prices)
        {
            return new BestPrice(new PriceInfo(0,0), new PriceInfo(0,0));
        }
    }
}
