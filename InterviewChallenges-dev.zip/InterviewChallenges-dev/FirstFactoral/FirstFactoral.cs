﻿namespace InterviewChallenges
{
    public class FirstFactoral
    {
        /*
        Given a non-negative integer, write a *Calculate()* method that returns factorial of a number.
       
        For example:

            Calculate(5) return 120 (5 * 4 * 3 * 2 * 1 = 120)
            Calculate(8) returns 40230 (8 * 7 * 6 * 5 * 4 * 3 * 2 * 1 = 40230)
        */
        public int Calculate(int startNum)
        {
            return startNum;
        }
    }
}
