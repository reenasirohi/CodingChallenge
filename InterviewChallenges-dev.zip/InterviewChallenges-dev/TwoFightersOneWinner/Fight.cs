﻿namespace InterviewChallenges
{
    public class Fight
    {
        /*
        Each fighter takes turns attacking the other and whoever kills the other first is victorious. Death is defined as having health <= 0. 
        Each fighter will be a instance of the *Fighter* class. Both health and damagePerAttack will be integers larger than 0. 

        Write some unit tests that determine the validity of thr *DeclareWinner()* function. An empty NUnit test class has been
        provided for you in the *TwoFightersOneWinnerTests* project.
         */

        public string DeclareWinner(Fighter fighter1, Fighter fighter2, string firstAttackerName)
        {
            static string battle(Fighter fighter1, Fighter fighter2)
            {
                do
                {
                    fighter2.Health -= fighter1.DamagePerAttack;
                    if (fighter2.Health > 0)
                        fighter1.Health -= fighter2.DamagePerAttack;
                }
                while (fighter2.Health > 0 && fighter1.Health > 0);

                return fighter1.Health > 0 ? fighter1.Name : fighter2.Name;
            }

            return fighter1.Name == firstAttackerName ? battle(fighter1, fighter2) : battle(fighter2, fighter1);
        }

    }
}
