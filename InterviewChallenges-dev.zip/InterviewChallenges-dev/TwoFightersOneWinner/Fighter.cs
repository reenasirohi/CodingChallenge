﻿namespace InterviewChallenges
{
    /// <summary>
    /// Class that defines a <see cref="Fighter"/>.
    /// </summary>
    public class Fighter
    {
        /// <summary>
        /// The fighters current health.
        /// </summary>
        public int Health { get; set; }

        /// <summary>
        /// The fighters name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The amount of damage per attack.
        /// </summary>
        public int DamagePerAttack { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name">The fighters name.</param>
        /// <param name="health">The fighters current health.</param>
        /// <param name="damagePerAttack">The amount of damage per attack.</param>
        public Fighter(string name, int health, int damagePerAttack)
        {
            this.Name = name;
            this.Health = health;
            this.DamagePerAttack = damagePerAttack;
        }
    }
}
