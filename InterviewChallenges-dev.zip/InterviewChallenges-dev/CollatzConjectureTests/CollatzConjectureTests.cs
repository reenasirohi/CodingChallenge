using NUnit.Framework;

namespace InterviewChallenges
{
    [TestFixture]
    public class CollatzConjectureTests
    {
        private CollatzConjecture collatz;

        [SetUp]
        public void Setup() => this.collatz = new CollatzConjecture();

        [TestCase(10, 6)]
        [TestCase(23, 15)]
        public void TestFindSteps(int input, int expected)
        {
            Assert.AreEqual(expected, this.collatz.FindSteps(input));
        }
    }
}