using NUnit.Framework;

namespace InterviewChallenges
{
    [TestFixture]
    public class FightTests
    {

    }
}