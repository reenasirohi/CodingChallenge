using NUnit.Framework;

namespace InterviewChallenges;

[TestFixture]
public class Tests
{
    private FirstFactoral fact;

    [SetUp]
    public void Setup() => this.fact = new FirstFactoral();

    [TestCase(5, 120)]
    [TestCase(8, 40320)]
    public void TestFactoral(int startNum, int total)
    {
        Assert.AreEqual(total, this.fact.Calculate(startNum));
    }
}