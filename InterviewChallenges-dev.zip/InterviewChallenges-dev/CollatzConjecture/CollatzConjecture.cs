﻿namespace InterviewChallenges
{
    public class CollatzConjecture
    {
        /*
        Consider the following operation on an arbitrary positive integer:

        If the number is even, divide it by two.
        If the number is odd, triple it and add one.

        The Collatz conjecture is: This process will eventually reach the number 1, regardless of which positive integer is chosen initially.
                
        Given an integer (n) consider the following operations:
        If n is even -> n / 2
        If n is odd -> n * 3 + 1

        Create a FindSteps() function to repeatedly evaluate these operations, until reaching 1 and return the number of steps it took. 

        For example:
            Given 10 as an input:

            10 is even - 10 / 2 = 5     -> step 1
            5 is odd - 5 * 3 + 1 = 16   -> step 2
            16 is even - 16 / 2 = 8     -> step 3
            8 is even - 8 / 2 = 4       -> step 4
            4 is even - 4 / 2 = 2       -> step 5
            2 is even - 2 / 2 = 1       -> step 6 (reached 1)
        */

        public int FindSteps(int number)
        {
            return 0;
        }
    }
}
