![Computershare](CPULogo.jpg)

## Welcome to your Computershare interview coding challenge!

We have several challenges that we'd like you to tackle - ranging in difficulty from *CityFinder.csproj* (easiest) to *StockPriceCalculator.csproj* (most difficult).

You can attempt as many as the challenges as you are comfortable with in **1 hour**, but we would recommend that you attempt a minimum of 3 challenges plus the *Two Fighters, One Winner*
challenge that requires unit tests to be added.

All the challenges (with the exception of *Two fighters, One Winner*) have failing unit tests present in a corresponding unit test project - so you can test your code as you go.

Try and complete as many of the challenges as you can - it will give us a better understanding of your skills as a developer. But most of all,
despite the fact that you are in an interview, try to have some fun!! :)

Information on all the challenges can be foung below. **Good luck.**

### City Finder:

Given a start letter and an end letter, write a *FindCity()* method that returns ALL cities that start and end with those letters from a given collection of cities.

For example:

    Given the array { "ROME","LONDON", "LISBON","NAIROBI","CALIFORNIA","ZURICH","NEW DELHI","AMSTERDAM","ABU DHABI", "PARIS" }
    
    FindCity('R', 'E') returns ["Rome"]
    FindCity('L', 'N') returns ("London", "Lisbon")

### First Factoral

Given a non-negative integer, write a *Calculate()* method that returns factorial of a number.
       
For example:

    Calculate(5) return 120 (5 * 4 * 3 * 2 * 1 = 120)
    Calculate(8) returns 40230 (8 * 7 * 6 * 5 * 4 * 3 * 2 * 1 = 40230)

### Collatz Conjecture

Consider the following operation on an arbitrary positive integer:

> If the number is even, divide it by two.
> 
> If the number is odd, triple it and add one.

The Collatz conjecture is: This process will eventually reach the number 1, regardless of which positive integer is chosen initially.
        
Given an integer (n) consider the following operations:
> If n is even -> n / 2

> If n is odd -> n * 3 + 1

Create a *FindSteps()* function to repeatedly evaluate these operations, until reaching 1 and return the number of steps it took. 

For example:

    Given 10 as an input:

    10 is even - 10 / 2 = 5     -> step 1
    5 is odd - 5 * 3 + 1 = 16   -> step 2
    16 is even - 16 / 2 = 8     -> step 3
    8 is even - 8 / 2 = 4       -> step 4
    4 is even - 4 / 2 = 2       -> step 5
    2 is even - 2 / 2 = 1       -> step 6 (reached 1)

### Array Shifting

 A rotation operation on an array shifts each of the array's elements to the left or right.
 
Given an integer and a direction, rotate the array that many steps left or right and return the resulting array.

 Create a *ShiftArray(int[] array, int steps, Direction direction)* function that takes 3 parameters:
- the integer array to manipulate
- an int denoting the number of steps left or right
- an enum value that denotes the direction

        ShiftArray([1, 2, 3, 4, 5], 2, Direction.Left)

        returns [3, 4, 5, 1, 2] because all elements after 0 and 1 have shifted left by 2

        ShiftArray([4, 5, 6, 7, 8, 9, 10, 11], 3, Direction.Right)

        returns [9, 10 ,11, 4, 5, 6, 7, 8] because all elements have moved right by 3

### Odd Number Triangle

Given the triangle of consecutive odd numbers:

                   1
                3     5
              7     9    11
          13    15    17    19
        21    23    25    27    29


Create a *CalculateRowTotal(int row)* function that returns the sum of the numbers in the nth row of this triangle (starting at index 1) 

For example:

        CalculateRowTotal(1) returns 1
        
        CalculateRowTotal(3) returns 27

### Stock Price Calculator

Given an array of doubles representing stock prices on each day of the month, create a *GetBuyAndSellDays()* function that returns the best day and price to buy and sell shares to 
make the maximum profit. Remember, you can't sell before you have bought, and you can't buy on the last day of the month.

For example:

        Given the dataset prices = [18.93,20.25,17.05,16.59,21.09,16.22,21.43,27.13,18.62,21.31,23.96,25.52,19.64,23.49,15.28,22.77,23.1,26.58,27.03,23.75,27.39,15.93,17.83,18.82,21.56,25.33,25,19.33,22.08,24.03]
        the best day to buy is day 15 [15,15.28] and the best day to sell is day 21 [21,27.39], so:

        GetBuyAndSellDay(prices) will return a BestPrice object containing:

            BestPrice.BuyDay = 15
            BestPrice.BuyPrice = 15.28
            BestPrice.SeellDay = 21
            BestPrice.SellPrice = 27.39

### Two Fighters, One Winner

Each fighter takes turns attacking the other and whoever kills the other first is victorious. Death is defined as having health <= 0. Each fighter will be a instance of the *Fighter* class. Both health and damagePerAttack will be integers larger than 0. 

Write some unit tests that determine the validity of thr *DeclareWinner()* function. An empty NUnit test class has been
provided for you in the *TwoFightersOneWinnerTests* project.
