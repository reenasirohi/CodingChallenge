using NUnit.Framework;

namespace InterviewChallenges
{
    [TestFixture]
    public class Tests
    {
        private ArrayShifting shifter;

        [SetUp]
        public void Setup() => this.shifter = new ArrayShifting();

        [TestCase(new [] { 1, 2, 3, 4, 5}, 2, new [] { 3, 4, 5, 1, 2})]
        [TestCase(new [] { 4, 5, 6, 7, 8, 9, 10, 11 }, 3, new [] { 7, 8, 9, 10, 11, 4, 5, 6 })]
        public void TestShiftLeft(int[] array, int noOfSteps, int[] expected)
        {
            //Assert.That(() => this.shifter.ShiftArray(array, noOfSteps, Direction.Left), Is.EquivalentTo(expected));
            CollectionAssert.AreEqual(this.shifter.ShiftArray(array, noOfSteps, Direction.Left), expected);
        }

        [TestCase(new[] { 1, 2, 3, 4, 5 }, 2, new[] { 4, 5, 1, 2, 3 })]
        [TestCase(new[] { 4, 5, 6, 7, 8, 9, 10, 11 }, 3, new[] { 9, 10, 11, 4, 5, 6, 7, 8})]
        public void TestShiftRight(int[] array, int noOfSteps, int[] expected)
        {
            //Assert.That(() => this.shifter.ShiftArray(array, noOfSteps, Direction.Right), Is.EquivalentTo(expected));
            CollectionAssert.AreEqual(this.shifter.ShiftArray(array, noOfSteps, Direction.Right), expected);
        }
    }
}