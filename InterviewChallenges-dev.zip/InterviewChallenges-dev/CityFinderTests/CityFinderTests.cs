using System.Linq;
using NUnit.Framework;

namespace InterviewChallenges
{
    [TestFixture]
    public class Tests
    {
        private CityFinder finder;

        [SetUp]
        public void Setup() => this.finder = new CityFinder();

        [TestCase('r', 'e', new[] { "ROME" })]
        [TestCase('l', 'n', new[] { "LONDON", "LISBON" })]
        public void TestFindCity(char start, char end, string[] expected)
        {
            Assert.That(expected.ToList(), Is.EquivalentTo(this.finder.FindCity(start, end)));
        }
    }
}