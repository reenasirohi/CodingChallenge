using NUnit.Framework;

namespace InterviewChallenges
{
    [TestFixture]
    public class PriceCalculatorTests
    {
        private PriceCalculator priceCalculator;

        [SetUp]
        public void Setup()
        {
            this.priceCalculator = new PriceCalculator();
        }

        [TestCase(15, 15.28D, 21, 27.39D, new[] {
            18.93, 20.25, 17.05, 16.59, 21.09, 16.22, 21.43, 27.13, 18.62, 21.31, 23.96, 25.52, 19.64, 23.49, 15.28,
            22.77, 23.1, 26.58, 27.03, 23.75, 27.39, 15.93, 17.83, 18.82, 21.56, 25.33, 25, 19.33, 22.08, 24.03
        })]
        [TestCase(20, 15.79D, 21, 26.19D, new[] {
            22.74, 22.27, 20.61, 26.15, 21.68, 21.51, 19.66, 24.11, 20.63, 20.96, 26.56, 26.67, 26.02, 27.20, 19.13,
            16.57, 26.71, 25.91, 17.51, 15.79, 26.19, 18.57, 19.03, 19.02, 19.97, 19.04, 21.06, 25.94, 17.03, 15.61
        })]
        [TestCase(18, 15.82D, 26, 27.17D, new[] {
            17.08, 19.55, 17.83, 23.20, 26.31, 26.77, 20.81, 26.57, 26.13, 17.06, 22.85, 24.94, 27.34, 21.71, 26.16,
            18.48, 22.80, 15.82, 21.02, 18.53, 25.22, 18.15, 23.96, 22.18, 15.91, 27.17, 20.26, 24.06, 26.36, 18.34
        })]
        public void TestCorrectPricesAndDaysReturned(int buyDay, double buyPrice, int sellDay, double sellPrice, double[] prices)
        {
            BestPrice bestPrice = this.priceCalculator.GetBuyAndSellDay(prices);

            Assert.AreEqual(buyDay, bestPrice.BuyInfo.Day);
            Assert.AreEqual(buyPrice, bestPrice.BuyInfo.Price);
            Assert.AreEqual(sellDay, bestPrice.SellInfo.Day);
            Assert.AreEqual(sellPrice, bestPrice.SellInfo.Price);
        }
    }
}