using System;
using NUnit.Framework;

namespace InterviewChallenges
{
    [TestFixture]
    public class OddNumberTriangleTests
    {
        private OddNumberTriangle oddNumberTriangle;

        [SetUp]
        public void SetUp()
        {
            this.oddNumberTriangle = new OddNumberTriangle();
        }

        [TestCase(1, 1)]
        [TestCase(2, 8)]
        [TestCase(3, 27)]
        [TestCase(4, 64)]
        [TestCase(5, 125)]
        public void TestCalculateRowTotal(int row, int expected)
        {
            Assert.AreEqual(expected, this.oddNumberTriangle.CalculateRowTotal(row));
        }

        [Test]
        public void TestCalculateRowTotal_GreaterThan5_Throws()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => this.oddNumberTriangle.CalculateRowTotal(6));
        }

    }
}