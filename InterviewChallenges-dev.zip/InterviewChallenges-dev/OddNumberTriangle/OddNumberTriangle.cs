﻿namespace InterviewChallenges
{
    /*     
    Given the triangle of consecutive odd numbers:

                   1                    Row 1
                3     5                 Row 2
              7     9    11             Row 3
          13    15    17    19          Row 4
        21    23    25    27    29      Row 5

    Create a CalculateRowTotal(int row) function that returns the sum of the numbers in the nth row of this triangle (starting at index 1) 
    
    For example:
        CalculateRowTotal(1) returns 1        
        CalculateRowTotal(3) returns 27 
    */

    public class OddNumberTriangle
    {
        /// <summary>
        /// Calculates the total of numbers in a given row of the triangle.
        /// </summary>
        /// <param name="row">The number of the row to calculate.</param>
        /// <returns>The total of the numbers in the row.</returns>
        public int CalculateRowTotal(int row)
        {
            return 0;
        }
    }
}
