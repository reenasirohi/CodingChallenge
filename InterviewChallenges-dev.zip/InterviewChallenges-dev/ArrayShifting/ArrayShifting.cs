﻿namespace InterviewChallenges
{
    // Denotes the direction in which to shift the array elements.
    public enum Direction
    {
        Left,
        Right
    }

    public class ArrayShifting
    {
        /*
        A rotation operation on an array shifts each of the array's elements to the left or right.
 
        Given an integer and a direction, rotate the array that many steps left or right and return the resulting array.

        Create a ShiftArray(int[] array, int steps, Direction direction) function that takes 3 parameters:
        - the integer array to manipulate
        - an int denoting the number of steps left or right
        - an enum value that denotes the direction

        ShiftArray([1, 2, 3, 4, 5], 2, Direction.Left)
        returns [3, 4, 5, 1, 2] because all elements after 0 and 1 have shifted left by 2

        ShiftArray([4, 5, 6, 7, 8, 9, 10, 11], 3, Direction.Right)
        returns [9, 10 ,11, 4, 5, 6, 7, 8] because all elements have moved right by 3 
        */

        public int[] ShiftArray(int[] array, int noOfSteps, Direction direction)
        {
            return array;
        }
    }
}
