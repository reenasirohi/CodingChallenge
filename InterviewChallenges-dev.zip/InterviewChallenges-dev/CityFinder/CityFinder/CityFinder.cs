﻿using System.Collections.Generic;

namespace InterviewChallenges
{
    public class CityFinder
    {
        /*
        Given a start letter and an end letter, write a FindCity() method that returns ALL cities that start and end with those letters from a given collection of cities.

        For example:

            Given the array { "ROME","LONDON", "LISBON","NAIROBI","CALIFORNIA","ZURICH","NEW DELHI","AMSTERDAM","ABU DHABI", "PARIS" }
            
            FindCity('R', 'E') returns ["Rome"]
            FindCity('L', 'N') returns ("London", "Lisbon")
         */

        string[] cities =
        {
            "ROME","LONDON", "LISBON","NAIROBI","CALIFORNIA","ZURICH","NEW DELHI","AMSTERDAM","ABU DHABI", "PARIS"
        };

        public IList<string> FindCity(char start, char end)
        {
            return this.cities;
        }

    }
}
